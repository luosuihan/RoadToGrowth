<?php
/**
 * Created by PhpStorm.
 * User: m1762
 * Date: 2019/2/26
 * Time: 14:32
 */
require_once 'framework\core\BookFramework.php';
new \framework\core\BookFramework();