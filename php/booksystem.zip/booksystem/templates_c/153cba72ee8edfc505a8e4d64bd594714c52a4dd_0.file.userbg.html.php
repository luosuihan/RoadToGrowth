<?php
/* Smarty version 3.1.30, created on 2019-02-28 11:18:56
  from "D:\code\htmlCode\H5text\php\booksystem\application\admin\view\userbg.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c7753205d2909_12911671',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '153cba72ee8edfc505a8e4d64bd594714c52a4dd' => 
    array (
      0 => 'D:\\code\\htmlCode\\H5text\\php\\booksystem\\application\\admin\\view\\userbg.html',
      1 => 1551322842,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c7753205d2909_12911671 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
管理员界面
</body>
</html><?php }
}
